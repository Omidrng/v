# Marzban-node
Read the setup guide here: https://gozargah.github.io/marzban/docs/marzban-node